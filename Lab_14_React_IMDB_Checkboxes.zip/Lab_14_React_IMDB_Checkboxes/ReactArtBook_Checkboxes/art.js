// note the name of the class must be capitalized 
class MyBookDisplay extends React.Component {
   constructor(props) {
      super(props)
      this.state = {
         selectedIndices: [3, 7],
         books: [],
         isLoading: true
      }
   }

   handleChange = e => {
      // I could change selctedIndices "directly" but it was not affecting the page
      // so I made a copy, changed the copy, and then used the copy to set the state
      let copy = this.state.selectedIndices;
      if (e.target.checked) {
         //add to selectedIndices
         copy.push(e.target.value);
         copy.sort(function (a, b) { return a - b });
         //sort() assumes strings ("10"<"9") -- added anonymous "compare" function to force number (9<10)
      } else {
         //remove from selectedIndices
         copy = copy.filter(function (element) {
            return element != e.target.value;
         });
      }
      this.setState({ selectedIndices: copy });
   }

   //note the JSON has a slightly different structure than before
   componentDidMount() {
      fetch('ArtAnatomy.json')
         .then(response => response.json())
         .then(data => this.setState({ books: data["books"], isLoading: false }));
   }

   render() {
      // The following code use React Fragment
      // Recall .map() is a way to loop over an array 
      // React requires you to pass in the key={} prop
      // https://reactjs.org/docs/lists-and-keys.html 

      /*
         we cannot do the real rendering until the data file is read (asynchronously) 
         hence the introduction of the isLoading attribute of the state 
      */
      if (this.state.isLoading) {
         return (<p>Loading ....</p>)
      } else {
         return (
            <>
               <h2>React Book Display -- Reading Data from JSON File</h2>
               {
                  this.state.books.map((book, i) => {
                     if (this.state.selectedIndices.indexOf(i) == -1) { //not found in selectedIndices array
                        //even though this is a map within a render it did not work with the single parent thing 
                        return (
                           <>
                              <img src={book.book_cover} key={"cover_" + i} />
                              <input key={"check_" + i} id={"book_" + i} type="checkbox" name="book" value={i} onChange={this.handleChange} />
                              <label key={"label_" + i} htmlFor={"book_" + i}>
                                 <span>{book.book_title}</span> ({book.book_isbn})
                              </label>
                              <br />
                           </>
                        )//match return of the if inside map 
                     }//match if
                     else { //found in selectedIndices array  -- add "checked" property
                        return (
                           <>
                              <img src={book.book_cover} key={"cover_" + i} />
                              <input key={"check_" + i} id={"book_" + i} type="checkbox" checked="checked" name="book" value={i} onChange={this.handleChange} />
                              <label key={"label_" + i} htmlFor={"book_" + i}>
                                 <span>{book.book_title}</span> ({book.book_isbn})
                              </label>
                              <br />
                           </>
                        ) //match return of the else inside map					
                     } //match else
                  }
                  )
               }
               <br /><br/>
               <h2>Books Selected</h2>
               {
                  this.state.selectedIndices.map((index, i) => (
                     <div>{this.state.books[index].book_title} ({this.state.books[index].book_author})</div>
                  ))
               }
            </>
         ) //match return in else of isLoading 
      } //match else of isLoading
   } //match render
} //end MyBookDisplay class

ReactDOM.render(<MyBookDisplay />, document.querySelector('#divBookDisplay'))