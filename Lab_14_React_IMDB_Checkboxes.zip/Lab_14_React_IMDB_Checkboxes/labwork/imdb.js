// note the name of the class must be capitalized 
class MyIMDBDisplay extends React.Component {
    constructor(props) {
       super(props)
       this.state = {
          selectedIndices: [3, 7],
          IMDBs: [],
          isLoading: true
       }
    }
 
    handleChange = e => {
       // I could change selctedIndices "directly" but it was not affecting the page
       // so I made a copy, changed the copy, and then used the copy to set the state
       let copy = this.state.selectedIndices;
       if (e.target.checked) {
          //add to selectedIndices
          copy.push(e.target.value);
          copy.sort(function (a, b) { return a - b });
          //sort() assumes strings ("10"<"9") -- added anonymous "compare" function to force number (9<10)
       } else {
          //remove from selectedIndices
          copy = copy.filter(function (element) {
             return element != e.target.value;
          });
       }
       this.setState({ selectedIndices: copy });
    }
 
    //note the JSON has a slightly different structure than before
    componentDidMount() {
       fetch('IMDB.json')
          .then(response => response.json())
          .then(data => this.setState({ IMDB: data["IMDB"], isLoading: false }));
    }
 
    render() {
       // The following code use React Fragment
       // Recall .map() is a way to loop over an array 
       // React requires you to pass in the key={} prop
       // https://reactjs.org/docs/lists-and-keys.html 
 
       /*
          we cannot do the real rendering until the data file is read (asynchronously) 
          hence the introduction of the isLoading attribute of the state 
       */
       if (this.state.isLoading) {
          return (<p>Loading ....</p>)
       } else {
          return (
             <>
                <h2>Lab 14 Jason Rosales</h2>
                {
                   this.state.IMDB.map((IMDB, i) => {
                      if (this.state.selectedIndices.indexOf(i) == -1) { //not found in selectedIndices array
                         //even though this is a map within a render it did not work with the single parent thing 
                         return (
                            <>
                               <img src={IMDB.IMDB_cover} key={"cover_" + i} />
                               <input key={"check_" + i} id={"IMDB_" + i} type="checkbox" name="IMDB" value={i} onChange={this.handleChange} />
                               <label key={"label_" + i} htmlFor={"IMDB_" + i}>
                                  <span>{IMDB.IMDB_title}</span> ({IMDB.IMDB_isbn})
                               </label>
                               <br />
                            </>
                         )//match return of the if inside map 
                      }//match if
                      else { //found in selectedIndices array  -- add "checked" property
                         return (
                            <>
                               <img src={IMDB.IMDB_cover} key={"cover_" + i} />
                               <input key={"check_" + i} id={"IMDB_" + i} type="checkbox" checked="checked" name="IMDB" value={i} onChange={this.handleChange} />
                               <label key={"label_" + i} htmlFor={"IMDB_" + i}>
                                  <span>{IMDB.IMDB_title}</span> ({IMDB.IMDB_isbn})
                               </label>
                               <br />
                            </>
                         ) //match return of the else inside map					
                      } //match else
                   }
                   )
                }
                <br /><br/>
                <h2>IMDB Selected</h2>
                {
                   this.state.selectedIndices.map((index, i) => (
                      <div>{this.state.IMDB[index].IMDB_title} ({this.state.IMDB[index].IMDB_author})</div>
                   ))
                }
             </>
          ) //match return in else of isLoading 
       } //match else of isLoading
    } //match render
 } //end MyBookDisplay class
 
 ReactDOM.render(<MyIMDBDisplay />, document.querySelector('#divIDMBDisplay'))